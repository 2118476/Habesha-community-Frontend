// HINT: Add these routes into your main router where <Routes> is defined:
//
// import Messages from './pages/Messages/Messages';
// <Route path="/app/messages" element={<Messages />} />
// <Route path="/app/messages/thread/:id" element={<Messages />} />
